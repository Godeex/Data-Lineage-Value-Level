# AgentDB 主动采样标注包（30 条，第二轮）

## 目的

这是 30 条**信息量最大**的 active-sampled query，用来把 30 条 pilot gold 扩到 60 条，验证：
- Literal∪Evolving vs machine reference（主结论）
- Evolving vs Fixed hybrid（自进化）
- join/case/cte 的 reference 盲区

**不需要 100+ 条**；60 条足够主结论，边界对比（vs reference∪static）留作 exploratory。

## 内容

- `ANNOTATION.md`：标注手册（三态、κ、仲裁）。
- `THEORY.md`：value-level lineage 定义。
- `sample_30_active.jsonl`：30 条 active query，含 `suggested_edges`（reference∪static∪literal，仅供参考）。
- `annotation_sheet.csv`：预填建议边，供逐条判定。
- `annotation_sheet_blank.csv`：空白表。
- `dbs/`：对应 SQLite 库。
- `inspect_db.py`：查看表结构。
- `compute_kappa.py`：两人 κ。
- `manifest.json`：SHA256。

## 怎么标

1. 先盲标（不看 `suggested_edges`），再对照。
2. 三态：POSITIVE / NEGATIVE / UNKNOWN；数据不足标 UNKNOWN。
3. 重点：join / case / cte；这些是 machine reference 的弱项。
4. 两人独立完成后用 `compute_kappa.py` 算 κ，分歧仲裁。

## 注意

- `suggested_edges` 是机器建议，**不是 gold**。
- 本地 Spider 值被匿名化（`v5_0` 等）；空结果/类型不匹配时标 UNKNOWN。
- 预计每人 60–90 分钟；两人 + 仲裁约 3–4 人时。

## 快速开始

```bash
python inspect_db.py dbs/concert_singer.sqlite
```
